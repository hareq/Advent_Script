# /**
#  * $Id: cd_cmd.py,v 1.1 2005/01/29 12:16:21 jkarthik Exp $
#  **/

##########################################################################
# Jython File	:- cd_cmd.py
# Author	    :- AdventNet Simulation Toolkit
#
#
# Explanation	:- To change the telnet working directory to specified one
#
##########################################################################

dir = scriptinterface.getCmdWord(2);
result = scriptinterface.changeDirectory(dir)
if result == 0:
	scriptinterface.strAppend("bash : cd: " + dir + ": No such 	file or directory")
