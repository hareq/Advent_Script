##########################################################################
# Jython File	:- DownloadFileUsingTFTP.py
# Date		:- Dec 29 2003 
# Author	:- AdventNet Simulation Toolkit
##########################################################################
# 
# Purpose	:- This script file is to download a file from the TFTP server
# 
# Syntax    	:- tl1scriptinterface.downloadFile (String ipAddress, int port, 
#		   String source, String target,  int mode, String protocol);
# 
# Explanation	:- This method is to download the 'source' file from the TFTP server 
#		   running at ipAddress and port to the 'target' file in 'mode' mode 
#		   using the 'protocol' protocol
#		   
# mode = 0 for netascii mode
# mode = 1 for octets mode
#
# 
##########################################################################
#
# The example for the DownloadFileUsingTFTP script method is

scriptinterface.downloadFile("127.0.0.1", 69, "testfile.txt", "testfile.txt",  0, "tftp");

# End of the file