The database values of the configuration are updated to the text file SimulatorDB.txt.
The following are the devices packaged.
dra
