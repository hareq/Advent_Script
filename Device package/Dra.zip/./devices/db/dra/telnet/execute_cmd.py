# /**
#  * $Id: execute_cmd.py,v 1.1 2005/01/29 12:15:37 jkarthik Exp $
#  **/

##########################################################################
# Jython File	:- execute_cmd.py
# Author	    :- AdventNet Simulation Toolkit
#
#
# Explanation	:- To execute the commands which does not have any output 
#				   display but remains director specific.Example : mkdir 
#
##########################################################################

command = scriptinterface.getCurrentCommand();
scriptinterface.executeTelnetCmd(command)

