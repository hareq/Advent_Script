# /**
#  * $Id: hostname_cmd.py,v 1.1 2005/01/29 12:12:45 jkarthik Exp $
#  **/

##########################################################################
# Jython File	:- hostname_cmd.py
# Author	    :- AdventNet Simulation Toolkit
#
#
# Explanation	:- To get the host name from telnet client
#
##########################################################################

host =  scriptinterface.getDeviceName()
scriptinterface.strAppend(host)
