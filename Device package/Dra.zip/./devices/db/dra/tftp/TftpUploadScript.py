##########################################################################
# Jython File	:- UploadFileUsingTFTP.py
# Date		:- Dec 29 2003 
# Author	:- AdventNet Simulation Toolkit
##########################################################################
# 
# Purpose	:- This script file is to upload a file to the TFTP server
# 
# Syntax    	:- tl1scriptinterface.uploadFile(String ipAddress, int port, 
#		   String source, String target,  int mode, String protocol);
# 
# Explanation	:- This method is to upload the 'source' file to the TFTP server 
#		   running at ipAddress and port as 'target' file in 'mode' mode 
#		   using the 'protocol' protocol
#		   
# mode = 0 for netascii mode
# mode = 1 for octets mode
#
# 
##########################################################################
#
# The example for the UploadFileUsingTFTP script method is

scriptinterface.uploadFile("127.0.0.1", 69, "testfile.txt", "testfile.txt",  0, "tftp");

# End of the file