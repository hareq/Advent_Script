# /**
#  * $Id: display_cmd.py,v 1.1 2005/01/29 12:16:06 jkarthik Exp $
#  **/

##########################################################################
# Jython File	:- display_cmd.py
# Author	:- AdventNet Simulation Toolkit
#
#
# Explanation	:- To execute the commands which has output display and 
#                  are directory specific.
#
##########################################################################

from java.util import StringTokenizer

command = scriptinterface.getCurrentCommand()
value = scriptinterface.execDisplayCommand(command)
strTok = StringTokenizer(value,"\n")
while strTok.hasMoreElements():
	str = strTok.nextToken()
	scriptinterface.strAppend(str)
	scriptinterface.strAppend("\r\n")

