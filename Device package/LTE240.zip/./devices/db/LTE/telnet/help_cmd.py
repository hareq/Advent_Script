# /**
#  * $Id: help_cmd.py,v 1.1 2005/01/29 12:13:06 jkarthik Exp $
#  **/

##########################################################################
# Jython File	:- help_cmd.py
# Author	    :- AdventNet Simulation Toolkit
#
#
# Explanation	:- To display the commands supported
#
##########################################################################

cmds=scriptinterface.getTelnetCommands(1);
scriptinterface.strAppend(cmds);
