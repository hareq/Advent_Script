# /**
#  * $Id: pwd_cmd.py,v 1.1 2005/01/29 12:12:20 jkarthik Exp $
#  **/

##########################################################################
# Jython File	:- pwd_cmd.py
# Author	:- AdventNet Simulation Toolkit
#
#
# Explanation	:- To get the current telnet working directory.
#
##########################################################################
root = scriptinterface.getTelnetRootDir();
scriptinterface.strAppend(root);

