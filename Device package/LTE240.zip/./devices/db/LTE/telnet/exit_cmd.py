# /**
#  * $Id: exit_cmd.py,v 1.1 2005/01/29 12:14:36 jkarthik Exp $
#  **/

##########################################################################
# Jython File	:- exit_cmd.py
# Author	    :- AdventNet Simulation Toolkit
#
#
# Explanation	:- To close the telnet connection
#
##########################################################################

scriptinterface.changeMode(8)
